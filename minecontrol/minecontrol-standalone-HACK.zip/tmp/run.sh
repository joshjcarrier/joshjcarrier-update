java -jar minecontrol-2.0.jar
